package version

func GetVersion() string {
	return version
}

var version = "2.4.1"
